"""
Failure Handler Lambda - Handle Mission Failures
Updates status and sends notifications when missions fail.
"""

import json
import boto3
import os
import logging
import time

logger = logging.getLogger()
logger.setLevel(logging.INFO)

dynamodb_client = boto3.client('dynamodb', region_name=os.environ.get('AWS_REGION', 'us-east-1'))
sns_client = boto3.client('sns', region_name=os.environ.get('AWS_REGION', 'us-east-1'))

MISSION_TABLE = os.environ.get('MISSION_TABLE', 'HivemindMissions')
SNS_TOPIC_ARN = os.environ.get('SNS_TOPIC_ARN', '')

def handler(event, context):
    """
    Handle mission failure.
    
    Input: {mission_id, error}
    """
    try:
        mission_id = event.get('mission_id', 'unknown')
        error = event.get('error', 'Unknown error')
        
        logger.error(f"Mission {mission_id} failed: {error}")
        
        # Update mission status
        dynamodb_client.update_item(
            TableName=MISSION_TABLE,
            Key={'mission_id': {'S': mission_id}},
            UpdateExpression='SET #status = :status, error_message = :error, last_updated = :updated',
            ExpressionAttributeNames={'#status': 'status'},
            ExpressionAttributeValues={
                ':status': {'S': 'FAILED'},
                ':error': {'S': error},
                ':updated': {'S': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
            }
        )
        
        # Send SNS notification if configured
        if SNS_TOPIC_ARN:
            sns_client.publish(
                TopicArn=SNS_TOPIC_ARN,
                Subject=f'Hivemind Mission Failed: {mission_id}',
                Message=json.dumps({
                    'mission_id': mission_id,
                    'status': 'FAILED',
                    'error': error,
                    'timestamp': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
                }, indent=2)
            )
        
        return {
            'status': 'failure_recorded',
            'mission_id': mission_id
        }
        
    except Exception as e:
        logger.error(f"Failure handler error: {str(e)}", exc_info=True)
        return {
            'status': 'error',
            'error': str(e)
        }